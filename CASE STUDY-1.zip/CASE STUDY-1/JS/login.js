$(document).ready(function(){

    function errortest()
    {
        setTimeout (function(){
        window.location.replace("main.html"); 
        },1000);
    }

    $("#button").click(function(e){
        e.preventDefault();
        
    if ($("#username").val()==""|| $("#password").val()=="")
    { 
    document.getElementById("error").innerHTML= "**Enter the Username & Password**";
    }

     if ($("#username").val()=="admin" &&  $("#password").val()=="12345")
    {    
        access (errortest)
    }
  
    function access(callback)
    {
        alert("Login Completed Successfully.");
        callback()
    }

     })

})



