
  document.getElementById("button1").style.visibility = "hidden";
  
  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
  
    if (this.readyState == 4 && this.status == 200) {
      $.getJSON("https://jsonplaceholder.typicode.com/todos", function (data) {
        
        var output = "";
        $.each(data, function (key, value) {
          
          output += `<tr><td>
          <div>
          <input type="checkbox" 
           ${value.completed? "disabled checked" : ""}>
           </div>
           </td>`;
          output += "<td>" + value.userId + "</td>";
          output += "<td>" + value.id + "</td>";
          output += "<td>" + value.title + "</td>";
          output += "<td>" + value.completed + "</td></tr>";
        });

        $("#api_list").append(output);
        
        let count = 0;

        $('input[type="checkbox"]').on("change", function () {
          if ($(this).prop("checked") === true) {
            count++;
          } 
          else {
            count--;
          }
          if (count == 5) {
            
            var promise = new Promise(function (resolve, reject) {
              resolve("Congrats!!! 5 Tasks have been Successfully Completed.");
            });
          }
          promise.then(function (alertMessage) {
            alert(alertMessage);
            count = 0;
            
          });
        });
      });
    }
  };
  xhttp.open("GET", "https://jsonplaceholder.typicode.com/todos", true);
  xhttp.send();


